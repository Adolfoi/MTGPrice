# -*- coding: utf-8 -*-

# Define here the models for your scraped items
#
# See documentation in:
# https://docs.scrapy.org/en/latest/topics/items.html

import scrapy


class MtgScrapyItem(scrapy.Item):
    # define the fields for your item here like:
    # name = scrapy.Field()
    card_name = scrapy.Field()
    card_price = scrapy.Field()
    card_stock = scrapy.Field()
    card_condition = scrapy.Field()
    card_text = scrapy.Field()
    card_setname = scrapy.Field()
    pass
