import datetime
import time
#import pygame
#from mutagen.mp3 import MP3 as mp3
from scrapy.spiderloader import SpiderLoader
from scrapy.crawler import CrawlerProcess
from scrapy.utils.project import get_project_settings


now = datetime.datetime.now()
dt_now_date = now.strftime("%Y-%m-%d-%H%M%S")
settings = get_project_settings()

settings.set('FEED_URI', 'mtg_hareruya' + '_' + dt_now_date + '.csv')
process = CrawlerProcess(settings)


# 'followall' is the name of one of the spiders of the project.
process.crawl('mtg_spider', domain='hareruyamtg.com')
process.start() # the script will block here until the crawling is finished

print("完了しました")
